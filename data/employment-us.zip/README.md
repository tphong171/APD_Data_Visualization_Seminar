US Employment and Unemployment rates since 1940. Official title: *Employment
status of the civilian noninstitutional population, 1940 to date* from USA
Bureau of Labor Statistics.

## Data

Numbers are in thousands.

US Employment and Unemployment rates since 1940 From the [USA Bureau of Labor Statistics Employment Related Data][faq]

[faq]: https://www.bls.gov/


## License

As US Federal Government data can assume Public Domain. Maintainer licenses any
additional rights from processing and structuring under Public Domain
Dedication and License.